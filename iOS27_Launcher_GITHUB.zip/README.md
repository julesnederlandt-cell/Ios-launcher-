# iOS 27 Style Launcher — GitHub APK Build

Projet Android Studio d'un launcher inspiré de l'esthétique iOS.

## Cette version est préparée pour GitHub Actions

Le workflow **n'a pas besoin du Gradle Wrapper** : GitHub télécharge automatiquement Gradle 8.9 avant de compiler.

### Installation sur GitHub

Après avoir décompressé ce ZIP, envoie **le contenu du dossier** dans ton dépôt GitHub, de façon à avoir directement à la racine :

```text
app/
.github/
build.gradle.kts
settings.gradle.kts
gradle.properties
```

Le fichier workflow doit être exactement ici :

```text
.github/workflows/build-apk.yml
```

Ensuite :

1. Ouvre **Actions**.
2. Choisis **Build APK**.
3. Appuie sur **Run workflow**.
4. Attends la fin du build.
5. Ouvre le build terminé.
6. Dans **Artifacts**, télécharge `iOS27-style-launcher-debug`.

### Ouvrir dans Android Studio

Ouvre le dossier extrait comme projet Android Studio. Gradle téléchargera les dépendances automatiquement.

## Fonctionnalités

- Interface de launcher inspirée d'iOS
- Dock translucide
- Widgets
- Recherche
- Bibliothèque d'applications
- Détection des applications installées
- Ouverture des applications
- Défilement entre pages
- Peut être déclaré comme launcher Android

Ce projet est une interface inspirée d'iOS et n'utilise pas les ressources propriétaires d'Apple.
