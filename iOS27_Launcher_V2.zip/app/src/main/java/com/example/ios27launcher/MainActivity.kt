package com.example.ios27launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppEntry(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)

private val iconColors = listOf(
    Color(0xFF5E72F4), Color(0xFF007AFF), Color(0xFF34C759),
    Color(0xFFFF2D55), Color(0xFFFF9500), Color(0xFFFFCC00),
    Color(0xFFAF52DE), Color(0xFF5856D6), Color(0xFF00C7BE),
    Color(0xFF111111), Color(0xFFF2F2F7)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherApp() }
    }
}

@Composable
fun LauncherApp() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppEntry>()) }
    var tint by remember { mutableStateOf(iconColors[0]) }
    var page by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { apps = queryApps(context) }

    val bg = Brush.verticalGradient(
        listOf(
            Color(0xFF8EC5FF),
            Color(0xFFCDE6FF),
            Color(0xFFF6F7FB)
        )
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(bg)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, drag ->
                    if (drag < -90) page = minOf(1, page + 1)
                    if (drag > 90) page = maxOf(0, page - 1)
                }
            }
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 15.dp)
        ) {
            TopBar(
                onSearch = { search = true },
                onSettings = { settings = true }
            )
            Spacer(Modifier.height(14.dp))

            AnimatedContent(targetState = page, label = "pages") { current ->
                if (current == 0) {
                    HomePage(apps, tint, context)
                } else {
                    LibraryPage(apps, tint, context)
                }
            }

            Spacer(Modifier.weight(1f))
            PageDots(page)
            Spacer(Modifier.height(8.dp))
            Dock(apps.take(4), tint, context)
            Spacer(Modifier.height(7.dp))
            Box(
                Modifier.align(Alignment.CenterHorizontally)
                    .width(112.dp).height(5.dp)
                    .clip(CircleShape).background(Color.Black.copy(.72f))
            )
        }

        if (search) {
            SearchScreen(
                apps = apps, tint = tint,
                onClose = { search = false },
                onLaunch = { launch(context, it) }
            )
        }

        if (settings) {
            SettingsSheet(
                current = tint,
                onColor = { tint = it },
                onClose = { settings = false }
            )
        }
    }
}

@Composable
fun TopBar(onSearch: () -> Unit, onSettings: () -> Unit) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) { now = Date(); delay(1000) }
    }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(time, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SignalCellularAlt, null, Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.Wifi, null, Modifier.size(18.dp))
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.BatteryFull, null, Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.Search, "Recherche",
                Modifier.size(23.dp).clickable { onSearch() })
            Spacer(Modifier.width(9.dp))
            Icon(Icons.Default.Settings, "Réglages",
                Modifier.size(22.dp).clickable { onSettings() })
        }
    }
}

@Composable
fun HomePage(apps: List<AppEntry>, tint: Color, context: Context) {
    Column {
        WeatherCard()
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            MiniWidget("Batterie", "87%", Icons.Default.BatteryFull, Modifier.weight(1f))
            MiniWidget("Musique", "Lecture", Icons.Default.MusicNote, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        val visible = apps.take(8)
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.height(260.dp),
            verticalArrangement = Arrangement.spacedBy(17.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            userScrollEnabled = false
        ) {
            items(visible) { AppIcon(it, tint) { launch(context, it) } }
        }
    }
}

@Composable
fun WeatherCard() {
    Card(
        Modifier.fillMaxWidth().height(170.dp),
        RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(Color.White.copy(.72f)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(21.dp), Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Column {
                    Text(
                        SimpleDateFormat("EEEE", Locale.FRENCH).format(Date()).uppercase(),
                        fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                    Text(
                        SimpleDateFormat("d MMMM", Locale.FRENCH).format(Date()),
                        fontWeight = FontWeight.Bold, fontSize = 28.sp
                    )
                }
                Icon(Icons.Default.WbSunny, null, Modifier.size(46.dp))
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text("18°", fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Text("Clair", fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun MiniWidget(title: String, value: String, icon: ImageVector, modifier: Modifier) {
    Card(
        modifier.height(92.dp), RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(Color.White.copy(.70f)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(14.dp), Arrangement.SpaceBetween) {
            Icon(icon, null, Modifier.size(20.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(value, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun AppIcon(app: AppEntry, tint: Color, onClick: () -> Unit) {
    val scale by animateFloatAsState(1f, tween(180), label = "scale")
    Column(
        Modifier.fillMaxWidth().clickable { onClick() }.alpha(scale),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(62.dp)
                .shadow(5.dp, RoundedCornerShape(18.dp), ambientColor = Color.Black.copy(.18f))
                .clip(RoundedCornerShape(18.dp))
                .background(tint),
            contentAlignment = Alignment.Center
        ) {
            Image(
                bitmap = app.icon.toBitmap(96, 96).asImageBitmap(),
                contentDescription = app.label,
                modifier = Modifier.size(46.dp),
                contentScale = ContentScale.Fit
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(app.label, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun LibraryPage(apps: List<AppEntry>, tint: Color, context: Context) {
    Column {
        Text("Bibliothèque", fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(apps) { AppIcon(it, tint) { launch(context, it) } }
        }
    }
}

@Composable
fun Dock(apps: List<AppEntry>, tint: Color, context: Context) {
    Box(
        Modifier.fillMaxWidth().height(96.dp)
            .clip(RoundedCornerShape(31.dp))
            .background(Color.White.copy(.58f))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(Modifier.fillMaxSize(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            apps.forEach { app ->
                Box(
                    Modifier.size(62.dp)
                        .shadow(5.dp, RoundedCornerShape(18.dp))
                        .clip(RoundedCornerShape(18.dp))
                        .background(tint)
                        .clickable { launch(context, app) },
                    Alignment.Center
                ) {
                    Image(
                        bitmap = app.icon.toBitmap(96, 96).asImageBitmap(),
                        contentDescription = app.label,
                        Modifier.size(46.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PageDots(page: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(2) { i ->
            Box(
                Modifier.size(if (i == page) 7.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(if (i == page) .75f else .28f))
            )
        }
    }
}

@Composable
fun SearchScreen(
    apps: List<AppEntry>,
    tint: Color,
    onClose: () -> Unit,
    onLaunch: (AppEntry) -> Unit
) {
    var q by remember { mutableStateOf("") }
    val filtered = apps.filter { it.label.contains(q, true) }

    Box(Modifier.fillMaxSize().background(Color(0xFFF7F7FA).copy(.98f)).padding(18.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, null) }
                OutlinedTextField(
                    q, { q = it }, Modifier.weight(1f),
                    placeholder = { Text("Rechercher") },
                    singleLine = true,
                    shape = RoundedCornerShape(23.dp)
                )
            }
            Spacer(Modifier.height(15.dp))
            filtered.take(30).forEach { app ->
                Row(
                    Modifier.fillMaxWidth().clickable { onLaunch(app) }.padding(vertical = 8.dp),
                    Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(tint),
                        Alignment.Center
                    ) {
                        Image(app.icon.toBitmap(72, 72).asImageBitmap(), app.label, Modifier.size(38.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(app.label, fontSize = 17.sp)
                }
            }
        }
    }
}

@Composable
fun SettingsSheet(current: Color, onColor: (Color) -> Unit, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(.22f))) {
        Card(
            Modifier.fillMaxWidth().align(Alignment.BottomCenter),
            RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            colors = CardDefaults.cardColors(Color(0xFFF7F7F9))
        ) {
            Column(Modifier.padding(22.dp)) {
                Text("Personnalisation", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                Text("Couleur des icônes", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(15.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    iconColors.take(6).forEach { c -> ColorButton(c, c == current) { onColor(c) } }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    iconColors.drop(6).forEach { c -> ColorButton(c, c == current) { onColor(c) } }
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    "La couleur est appliquée à l'arrière-plan des icônes du launcher.",
                    fontSize = 13.sp, color = Color.DarkGray
                )
                Spacer(Modifier.height(14.dp))
                Button(onClick = onClose, Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Text("Terminé")
                }
            }
        }
    }
}

@Composable
fun ColorButton(color: Color, selected: Boolean, onClick: () -> Unit) {
    val border by animateColorAsState(
        if (selected) Color.Black else Color.Transparent, label = "border"
    )
    Box(
        Modifier.size(39.dp).clip(CircleShape)
            .background(color)
            .clickable { onClick() }
            .padding(3.dp),
        Alignment.Center
    ) {
        if (selected) {
            Box(Modifier.size(31.dp).clip(CircleShape).background(color)) {
                Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

fun queryApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .map { info: ResolveInfo ->
            AppEntry(
                info.loadLabel(pm).toString(),
                info.activityInfo.packageName,
                info.activityInfo.name,
                info.loadIcon(pm)
            )
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase(Locale.getDefault()) }
}

fun launch(context: Context, app: AppEntry) {
    val intent = Intent().apply {
        setClassName(app.packageName, app.activityName)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
}
