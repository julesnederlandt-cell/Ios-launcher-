# iOS 27 Style Launcher V2

Launcher Android inspiré de l'esthétique iOS.

## V2
- vraies icônes des applications installées
- couleur personnalisable pour les icônes
- sélection de couleurs
- dock translucide
- widgets
- bibliothèque d'applications
- recherche
- pages par balayage
- animations Compose
- launcher HOME Android
- workflow GitHub Actions pour générer l'APK

## GitHub
Pour compiler, le contenu du projet doit être présent dans le dépôt avec `.github/workflows/build-apk.yml`.
GitHub ne peut pas exécuter un workflow qui reste enfermé dans une archive ZIP non extraite.

L'APK de debug est produit dans :
`app/build/outputs/apk/debug/app-debug.apk`
