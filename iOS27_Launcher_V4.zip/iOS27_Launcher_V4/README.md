# iOS 27 Launcher V4

A standalone Android launcher inspired by modern iOS-style home screens. It is an original implementation and does not include Apple assets or code.

## What is in V4
- Real Android launcher intent (HOME/DEFAULT)
- Reads installed launcher apps from PackageManager
- Multi-page home screen with swipe
- Real app icons and launching
- Search/library view
- Control Center-style overlay
- Battery percentage from the device
- Weather/music widgets as visual launcher widgets
- Dark mode
- Accent-color cycling
- Monochrome icon mode
- Settings panel with default-launcher shortcut
- Edge-to-edge rendering
- GitHub Actions build workflow

## GitHub
Push the complete folder to the repository root. Actions > Build APK V4 > Run workflow. The APK appears under Artifacts.
