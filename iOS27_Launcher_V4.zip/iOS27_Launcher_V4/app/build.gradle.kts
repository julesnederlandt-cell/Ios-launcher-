plugins { id("com.android.application") }

android { namespace = "com.jules.ioslauncher"; compileSdk = 35
    defaultConfig { applicationId = "com.jules.ioslauncher"; minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "4.0" }
}
