package com.jules.ioslauncher;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) c.setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        } else { w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
        FrameLayout root = new FrameLayout(this);
        LauncherView launcher = new LauncherView(this);
        root.addView(launcher, new FrameLayout.LayoutParams(-1, -1));
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(Color.BLACK); search.setTextSize(15);
        search.setHint("Search apps"); search.setHintTextColor(0xFF777777);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(12,0,12,0);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, (int)(47 * getResources().getDisplayMetrics().density));
        sp.leftMargin = (int)(28 * getResources().getDisplayMetrics().density); sp.rightMargin = (int)(28 * getResources().getDisplayMetrics().density);
        sp.topMargin = (int)(98 * getResources().getDisplayMetrics().density);
        search.setVisibility(View.GONE);
        root.addView(search, sp);
        launcher.searchEditor = search;
        search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){ launcher.query=s.toString(); launcher.updateShown(); launcher.invalidate(); } public void afterTextChanged(Editable e){} });
        setContentView(root);
    }
}
