# iOS27 Launcher V4.1

Android launcher inspired by modern iOS visual design.

## Build on GitHub
The repository root must contain:
- settings.gradle.kts
- build.gradle.kts
- app/
- gradle/
- .github/workflows/build-apk.yml

GitHub Actions runs Gradle 8.9 + JDK 17 and uploads the debug APK.

## Build in Android Studio
Open this folder as an existing Gradle project. Android Studio can use its configured Gradle distribution. The GitHub workflow does not need to be used for local builds.

## Features
- Real installed-app discovery and launching
- Home pages with swipe
- App search
- App Library
- Control Center-style panel
- Battery widget
- Dark mode
- Monochrome icon tint
- Accent color cycling
- Default launcher settings shortcut
- Wallpaper chooser
