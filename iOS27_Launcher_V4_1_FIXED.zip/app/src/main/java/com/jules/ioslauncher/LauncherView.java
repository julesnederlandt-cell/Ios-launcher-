package com.jules.ioslauncher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LauncherView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Context context;
    private final PackageManager packageManager;
    private final ArrayList<AppInfo> apps = new ArrayList<>();
    private final ArrayList<AppInfo> shown = new ArrayList<>();
    private final SharedPreferences prefs;

    EditText searchEditor;
    String query = "";

    private int page = 0;
    private float downX;
    private float downY;

    private boolean searchMode = false;
    private boolean libraryMode = false;
    private boolean controlMode = false;
    private boolean settingsMode = false;
    private boolean darkMode;
    private boolean monochrome;

    private int accent;
    private final int[] accents = {
        Color.rgb(93, 110, 245),
        Color.rgb(255, 86, 120),
        Color.rgb(54, 180, 110),
        Color.rgb(255, 170, 60),
        Color.rgb(120, 90, 220)
    };

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    LauncherView(Context context) {
        super(context);
        this.context = context;
        this.packageManager = context.getPackageManager();
        this.prefs = context.getSharedPreferences("ios27_launcher_v4", Context.MODE_PRIVATE);

        this.accent = prefs.getInt("accent", accents[0]);
        this.darkMode = prefs.getBoolean("dark", false);
        this.monochrome = prefs.getBoolean("mono", false);

        textPaint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        setFocusable(true);
        loadApps();
    }

    private void loadApps() {
        apps.clear();

        Intent launcherIntent = new Intent(Intent.ACTION_MAIN);
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> results = packageManager.queryIntentActivities(
            launcherIntent, PackageManager.MATCH_ALL
        );

        for (ResolveInfo result : results) {
            if (result.activityInfo == null) continue;
            if (result.activityInfo.packageName.equals(context.getPackageName())) continue;

            AppInfo app = new AppInfo();
            app.label = result.loadLabel(packageManager).toString();
            app.icon = result.loadIcon(packageManager);
            app.packageName = result.activityInfo.packageName;
            app.className = result.activityInfo.name;
            apps.add(app);
        }

        Collections.sort(apps, (a, b) ->
            a.label.compareToIgnoreCase(b.label)
        );

        updateShown();
    }

    void updateShown() {
        shown.clear();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.getDefault());

        for (AppInfo app : apps) {
            if (q.isEmpty() || app.label.toLowerCase(Locale.getDefault()).contains(q)) {
                shown.add(app);
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();

        int top = darkMode ? Color.rgb(18, 20, 28) : Color.rgb(222, 236, 255);
        int bottom = darkMode ? Color.rgb(8, 10, 15) : Color.rgb(241, 246, 255);

        paint.setShader(new LinearGradient(
            0, 0, 0, height, top, bottom, Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0, 0, width, height, paint);
        paint.setShader(null);

        drawStatusBar(canvas, width);

        if (settingsMode) {
            drawSettings(canvas, width, height);
            return;
        }

        if (controlMode) {
            drawControlCenter(canvas, width, height);
            return;
        }

        if (searchMode || libraryMode) {
            drawLibrary(canvas, width, height);
            return;
        }

        drawHome(canvas, width, height);
    }

    private void drawStatusBar(Canvas canvas, int width) {
        textPaint.setColor(darkMode ? Color.WHITE : Color.BLACK);
        textPaint.setTextSize(dp(15));
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);

        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        canvas.drawText(time, dp(22), dp(31), textPaint);

        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setTextSize(dp(12));
        canvas.drawText("5G  •  " + battery() + "%", width - dp(20), dp(31), textPaint);
        textPaint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawHome(Canvas canvas, int width, int height) {
        drawWidget(
            canvas, dp(18), dp(55), width - dp(18), dp(210),
            "Weather",
            new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new Date()),
            "18°  Clear"
        );

        drawWidget(
            canvas, dp(18), dp(225), width / 2f - dp(7), dp(325),
            "Battery", "Device", battery() + "%"
        );

        drawWidget(
            canvas, width / 2f + dp(7), dp(225), width - dp(18), dp(325),
            "Music", "Now Playing", "›"
        );

        int columns = 4;
        float gap = dp(13);
        float cell = (width - dp(36) - gap * 3) / 4f;
        float y = dp(355);
        int start = page * 20;

        for (int i = 0; i < 20; i++) {
            int index = start + i;
            if (index >= apps.size()) break;

            int column = i % columns;
            int row = i / columns;

            float x = dp(18) + column * (cell + gap);
            drawApp(canvas, apps.get(index), x, y + row * dp(92), cell);
        }

        drawPageDots(canvas, width, height);
        drawDock(canvas, width, height);
    }

    private void drawWidget(Canvas canvas, float left, float top, float right, float bottom,
                            String title, String subtitle, String value) {
        paint.setColor(darkMode ? 0x55262A34 : 0xCCF8FBFF);
        canvas.drawRoundRect(left, top, right, bottom, dp(28), dp(28), paint);

        textPaint.setColor(darkMode ? Color.WHITE : Color.BLACK);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(14));
        canvas.drawText(title, left + dp(18), top + dp(27), textPaint);

        textPaint.setTypeface(Typeface.DEFAULT);
        textPaint.setTextSize(dp(13));
        canvas.drawText(subtitle, left + dp(18), top + dp(55), textPaint);

        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(25));
        canvas.drawText(value, left + dp(18), bottom - dp(20), textPaint);
        textPaint.setTypeface(Typeface.DEFAULT);
    }

    private void drawApp(Canvas canvas, AppInfo app, float x, float y, float cell) {
        float size = dp(62);
        float iconX = x + (cell - size) / 2f;

        Drawable drawable = app.icon;
        drawable.setBounds(
            (int) iconX, (int) y,
            (int) (iconX + size), (int) (y + size)
        );

        if (monochrome) {
            drawable.setColorFilter(new PorterDuffColorFilter(accent, PorterDuff.Mode.SRC_IN));
        } else {
            drawable.clearColorFilter();
        }

        drawable.draw(canvas);

        textPaint.setColor(darkMode ? Color.WHITE : Color.rgb(20, 20, 25));
        textPaint.setTextSize(dp(11));
        textPaint.setTextAlign(Paint.Align.CENTER);

        String name = app.label.length() > 12
            ? app.label.substring(0, 11) + "…"
            : app.label;

        canvas.drawText(name, x + cell / 2f, y + size + dp(18), textPaint);
        textPaint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawPageDots(Canvas canvas, int width, int height) {
        int pages = Math.max(1, (apps.size() + 19) / 20);
        pages = Math.min(pages, 5);

        paint.setColor(darkMode ? Color.WHITE : Color.DKGRAY);

        float start = width / 2f - ((pages - 1) * dp(5));
        for (int i = 0; i < pages; i++) {
            canvas.drawCircle(
                start + i * dp(10),
                height - dp(132),
                dp(i == page ? 4 : 3),
                paint
            );
        }
    }

    private void drawDock(Canvas canvas, int width, int height) {
        float left = dp(16);
        float top = height - dp(105);
        float right = width - dp(16);
        float bottom = height - dp(20);

        paint.setColor(darkMode ? 0xAA20232C : 0xD9FFFFFF);
        canvas.drawRoundRect(left, top, right, bottom, dp(30), dp(30), paint);

        int count = Math.min(4, apps.size());
        if (count == 0) return;

        float size = dp(56);
        float usable = right - left - dp(44) - size;

        for (int i = 0; i < count; i++) {
            AppInfo app = apps.get(i);
            float x = left + dp(22);
            if (count > 1) {
                x += i * (usable / (count - 1));
            }

            Drawable drawable = app.icon;
            drawable.clearColorFilter();
            drawable.setBounds(
                (int) x, (int) (top + dp(14)),
                (int) (x + size), (int) (top + dp(14) + size)
            );
            drawable.draw(canvas);
        }
    }

    private void drawLibrary(Canvas canvas, int width, int height) {
        textPaint.setColor(darkMode ? Color.WHITE : Color.BLACK);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(30));
        canvas.drawText(libraryMode ? "App Library" : "Search", dp(20), dp(80), textPaint);

        paint.setColor(darkMode ? 0x55343A48 : 0xBFFFFFFF);
        canvas.drawRoundRect(
            dp(18), dp(98), width - dp(18), dp(145),
            dp(22), dp(22), paint
        );

        textPaint.setTypeface(Typeface.DEFAULT);
        textPaint.setTextSize(dp(15));
        textPaint.setColor(darkMode ? Color.WHITE : Color.DKGRAY);
        canvas.drawText(
            query.isEmpty() ? "⌕  Search apps" : "⌕  " + query,
            dp(34), dp(128), textPaint
        );

        int columns = 4;
        float gap = dp(13);
        float cell = (width - dp(36) - gap * 3) / 4f;

        int max = Math.min(28, shown.size());
        for (int i = 0; i < max; i++) {
            int column = i % columns;
            int row = i / columns;
            float x = dp(18) + column * (cell + gap);
            drawApp(canvas, shown.get(i), x, dp(170) + row * dp(92), cell);
        }
    }

    private void drawControlCenter(Canvas canvas, int width, int height) {
        paint.setColor(darkMode ? 0xEE10131A : 0xEEF4F7FF);
        canvas.drawRoundRect(
            dp(10), dp(55), width - dp(10), height - dp(10),
            dp(34), dp(34), paint
        );

        textPaint.setColor(darkMode ? Color.WHITE : Color.BLACK);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(25));
        canvas.drawText("Control Center", dp(28), dp(98), textPaint);

        textPaint.setTypeface(Typeface.DEFAULT);

        drawTile(canvas, dp(25), dp(125), width / 2f - dp(10), dp(205),
            "Wi-Fi", "Connected", true);
        drawTile(canvas, width / 2f + dp(10), dp(125), width - dp(25), dp(205),
            "Bluetooth", "On", true);
        drawTile(canvas, dp(25), dp(220), width / 2f - dp(10), dp(300),
            "Focus", "Off", false);
        drawTile(canvas, width / 2f + dp(10), dp(220), width - dp(25), dp(300),
            "AirDrop", "Contacts", false);
    }

    private void drawTile(Canvas canvas, float left, float top, float right, float bottom,
                           String title, String subtitle, boolean enabled) {
        paint.setColor(enabled ? accent : (darkMode ? 0xFF292E38 : 0xFFE5EAF2));
        canvas.drawRoundRect(left, top, right, bottom, dp(24), dp(24), paint);

        textPaint.setColor(enabled ? Color.WHITE : (darkMode ? Color.WHITE : Color.BLACK));
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(15));
        canvas.drawText(title, left + dp(15), top + dp(28), textPaint);

        textPaint.setTypeface(Typeface.DEFAULT);
        textPaint.setTextSize(dp(12));
        canvas.drawText(subtitle, left + dp(15), top + dp(50), textPaint);
    }

    private void drawSettings(Canvas canvas, int width, int height) {
        paint.setColor(darkMode ? 0xF5161820 : 0xF7F8FAFF);
        canvas.drawRoundRect(
            dp(10), dp(55), width - dp(10), height - dp(10),
            dp(34), dp(34), paint
        );

        textPaint.setColor(darkMode ? Color.WHITE : Color.BLACK);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(27));
        canvas.drawText("Launcher Settings", dp(28), dp(100), textPaint);
        textPaint.setTypeface(Typeface.DEFAULT);

        drawSwitchRow(canvas, dp(25), dp(130), width - dp(25), "Dark mode", darkMode);
        drawSwitchRow(canvas, dp(25), dp(195), width - dp(25), "Monochrome icons", monochrome);
        drawTextRow(canvas, dp(25), dp(260), width - dp(25), "Accent color", "Tap to cycle");
        drawTextRow(canvas, dp(25), dp(325), width - dp(25),
            "Set as default launcher", "Open Home settings");
        drawTextRow(canvas, dp(25), dp(395), width - dp(25),
            "Wallpaper", "Choose device wallpaper");
    }

    private void drawSwitchRow(Canvas canvas, float left, float top, float right,
                                String label, boolean enabled) {
        textPaint.setColor(darkMode ? Color.WHITE : Color.BLACK);
        textPaint.setTextSize(dp(15));
        canvas.drawText(label, left, top + dp(25), textPaint);

        paint.setColor(enabled ? accent : (darkMode ? 0xFF444A55 : 0xFFD8DCE5));
        canvas.drawRoundRect(
            right - dp(55), top, right, top + dp(32), dp(18), dp(18), paint
        );

        paint.setColor(Color.WHITE);
        canvas.drawCircle(
            enabled ? right - dp(39) : right - dp(48),
            top + dp(16), dp(11), paint
        );
    }

    private void drawTextRow(Canvas canvas, float left, float top, float right,
                             String title, String subtitle) {
        textPaint.setColor(darkMode ? Color.WHITE : Color.BLACK);
        textPaint.setTextSize(dp(15));
        canvas.drawText(title, left, top + dp(23), textPaint);

        textPaint.setColor(darkMode ? 0xFFB8BEC8 : 0xFF666A72);
        textPaint.setTextSize(dp(12));
        canvas.drawText(subtitle, left, top + dp(43), textPaint);
    }

    private int battery() {
        BatteryManager manager =
            (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);

        if (manager == null) return 0;

        int value = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        return value < 0 ? 0 : value;
    }

    private void launch(AppInfo app) {
        try {
            Intent intent = new Intent();
            intent.setClassName(app.packageName, app.className);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    private void openSearch() {
        searchMode = true;
        libraryMode = false;
        query = "";
        updateShown();

        if (searchEditor != null) {
            searchEditor.setText("");
            searchEditor.setVisibility(VISIBLE);
            searchEditor.requestFocus();
        }
    }

    private void closeOverlay() {
        searchMode = false;
        libraryMode = false;
        controlMode = false;
        settingsMode = false;

        if (searchEditor != null) {
            searchEditor.setVisibility(GONE);
            searchEditor.clearFocus();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            downX = x;
            downY = y;
            return true;
        }

        if (event.getAction() != MotionEvent.ACTION_UP) return true;

        float dx = x - downX;

        if (settingsMode) {
            if (y > dp(130) && y < dp(195)) {
                darkMode = !darkMode;
                prefs.edit().putBoolean("dark", darkMode).apply();
            } else if (y > dp(195) && y < dp(260)) {
                monochrome = !monochrome;
                prefs.edit().putBoolean("mono", monochrome).apply();
            } else if (y > dp(260) && y < dp(325)) {
                cycleAccent();
            } else if (y > dp(325) && y < dp(395)) {
                try {
                    context.startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                } catch (Exception ignored) {
                }
            } else if (y > dp(395) && y < dp(475)) {
                try {
                    Intent wallpaper = new Intent(Intent.ACTION_SET_WALLPAPER);
                    context.startActivity(Intent.createChooser(wallpaper, "Choose wallpaper"));
                } catch (Exception ignored) {
                }
            } else if (y < dp(125)) {
                settingsMode = false;
            }

            invalidate();
            return true;
        }

        if (controlMode) {
            if (y < dp(115)) {
                controlMode = false;
                invalidate();
            }
            return true;
        }

        if (searchMode || libraryMode) {
            if (y >= dp(155)) {
                float gap = dp(13);
                float cell = (getWidth() - dp(36) - gap * 3) / 4f;
                int column = (int) ((x - dp(18)) / (cell + gap));
                int row = (int) ((y - dp(170)) / dp(92));

                if (column >= 0 && column < 4 && row >= 0) {
                    int index = row * 4 + column;
                    if (index >= 0 && index < shown.size()) {
                        launch(shown.get(index));
                    }
                }
            }

            if (dx > dp(120)) {
                closeOverlay();
                invalidate();
            }

            return true;
        }

        if (Math.abs(dx) > dp(120)) {
            int maxPage = Math.max(0, (apps.size() - 1) / 20);
            if (dx < 0 && page < maxPage) page++;
            if (dx > 0 && page > 0) page--;
            invalidate();
            return true;
        }

        if (y < dp(55) && x > getWidth() - dp(95)) {
            controlMode = true;
            invalidate();
            return true;
        }

        if (y < dp(55) && x < dp(100)) {
            openSearch();
            invalidate();
            return true;
        }

        if (y > getHeight() - dp(135)) {
            return true;
        }

        if (y > dp(355) && y < getHeight() - dp(120)) {
            float gap = dp(13);
            float cell = (getWidth() - dp(36) - gap * 3) / 4f;

            int column = (int) ((x - dp(18)) / (cell + gap));
            int row = (int) ((y - dp(355)) / dp(92));

            if (column >= 0 && column < 4 && row >= 0 && row < 5) {
                int index = page * 20 + row * 4 + column;
                if (index >= 0 && index < apps.size()) {
                    launch(apps.get(index));
                }
            }
        }

        // Tap the bottom-center dock area to open settings.
        if (y > getHeight() - dp(130)
                && x > getWidth() / 2f - dp(80)
                && x < getWidth() / 2f + dp(80)) {
            settingsMode = true;
            invalidate();
        }

        return true;
    }

    private void cycleAccent() {
        int index = 0;
        for (int i = 0; i < accents.length; i++) {
            if (accents[i] == accent) {
                index = i;
                break;
            }
        }

        accent = accents[(index + 1) % accents.length];
        prefs.edit().putInt("accent", accent).apply();
    }

    static class AppInfo {
        String label;
        String packageName;
        String className;
        Drawable icon;
    }
}
