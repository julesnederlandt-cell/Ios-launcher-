plugins {
    id("com.android.application")
}

android {
    namespace = "com.jules.ioslauncher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jules.ioslauncher"
        minSdk = 26
        targetSdk = 35
        versionCode = 42
        versionName = "4.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
        }
    }
}
