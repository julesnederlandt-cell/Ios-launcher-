# iOS 27 Style Launcher for Android

Projet Android Studio d'un launcher **inspiré de l'esthétique iOS**, sans utiliser les fichiers propriétaires d'Apple.

## Fonctionnalités

- Écran d'accueil façon iOS
- Widgets météo / batterie / musique
- Grille d'applications
- Dock translucide
- Recherche d'applications
- Bibliothèque d'applications
- Ouverture des applications installées
- Détection des applications du téléphone
- Geste horizontal entre les pages
- Déclaration comme application HOME / launcher
- GitHub Actions pour compiler automatiquement l'APK

## Ouvrir dans Android Studio

1. Décompresse le ZIP.
2. Ouvre le dossier `iOS27_Style_Launcher` avec Android Studio.
3. Laisse Gradle télécharger les dépendances.
4. Lance `app` sur ton téléphone ou un émulateur.

## Créer l'APK avec GitHub

1. Crée un dépôt GitHub.
2. Envoie tous les fichiers du projet.
3. Va dans **Actions**.
4. Lance **Build APK** avec **Run workflow**.
5. Une fois terminé, récupère l'APK dans les **Artifacts**.

## Important

Ce projet reproduit une esthétique de launcher moderne inspirée d'iOS, mais ce n'est pas une copie exacte du système iOS et n'utilise pas les ressources propriétaires d'Apple.
