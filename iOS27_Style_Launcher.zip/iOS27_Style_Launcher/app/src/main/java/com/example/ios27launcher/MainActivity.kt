package com.example.ios27launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

data class LauncherApp(
    val label: String,
    val icon: ImageVector,
    val color: Color,
    val packageName: String? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(android.graphics.Color.TRANSPARENT)
        window.setNavigationBarColor(android.graphics.Color.TRANSPARENT)

        setContent {
            MaterialTheme {
                LauncherScreen()
            }
        }
    }
}

@Composable
fun LauncherScreen() {
    val context = LocalContext.current
    var page by remember { mutableIntStateOf(0) }
    var searchOpen by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(emptyList<LauncherApp>()) }

    LaunchedEffect(Unit) {
        apps = loadApps(context)
    }

    val background = Brush.verticalGradient(
        listOf(
            Color(0xFFB9D9FF),
            Color(0xFFDDEBFF),
            Color(0xFFF7F7F9)
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(background)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        // Lightweight page gesture; the launcher remains responsive
                    },
                    onHorizontalDrag = { _, dragAmount ->
                        if (dragAmount < -120) page = minOf(page + 1, 1)
                        if (dragAmount > 120) page = maxOf(page - 1, 0)
                    }
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 18.dp, start = 18.dp, end = 18.dp, bottom = 10.dp)
        ) {
            StatusHeader(
                onSearch = { searchOpen = true },
                onSettings = {
                    context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                }
            )

            Spacer(Modifier.height(14.dp))

            if (page == 0) {
                HeroWidget()
                Spacer(Modifier.height(16.dp))
                QuickWidgets()
                Spacer(Modifier.height(16.dp))
                AppGrid(
                    apps = if (apps.isNotEmpty()) apps.take(8) else demoApps(),
                    onLaunch = { launchApp(context, it) }
                )
            } else {
                AppLibrary(
                    apps = if (apps.isNotEmpty()) apps else demoApps(),
                    onLaunch = { launchApp(context, it) }
                )
            }

            Spacer(Modifier.weight(1f))
            PageIndicator(page)
            Spacer(Modifier.height(8.dp))
            Dock(
                apps = apps.take(4).ifEmpty { demoApps().take(4) },
                onLaunch = { launchApp(context, it) }
            )
            Spacer(Modifier.height(5.dp))
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .width(110.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = .75f))
            )
        }

        AnimatedVisibility(
            visible = searchOpen,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SearchOverlay(
                apps = apps,
                onClose = { searchOpen = false },
                onLaunch = {
                    searchOpen = false
                    launchApp(context, it)
                }
            )
        }
    }
}

@Composable
fun StatusHeader(onSearch: () -> Unit, onSettings: () -> Unit) {
    val now = remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now.value = Date()
            kotlinx.coroutines.delay(1000)
        }
    }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now.value)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(time, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SignalCellularAlt, null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.Wifi, null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.BatteryFull, null, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(9.dp))
            Icon(
                Icons.Default.Search, null,
                modifier = Modifier.size(22.dp).clickable { onSearch() }
            )
            Spacer(Modifier.width(8.dp))
            Icon(
                Icons.Default.Settings, null,
                modifier = Modifier.size(21.dp).clickable { onSettings() }
            )
        }
    }
}

@Composable
fun HeroWidget() {
    Card(
        modifier = Modifier.fillMaxWidth().height(170.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .76f)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("JEUDI", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        SimpleDateFormat("d MMMM", Locale.getDefault()).format(Date()),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Icon(Icons.Default.WbSunny, null, modifier = Modifier.size(42.dp))
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text("18°", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text("Clair", fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun QuickWidgets() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SmallWidget("Batterie", "87%", Icons.Default.BatteryFull, Modifier.weight(1f))
        SmallWidget("Musique", "Lecture", Icons.Default.MusicNote, Modifier.weight(1f))
    }
}

@Composable
fun SmallWidget(title: String, value: String, icon: ImageVector, modifier: Modifier) {
    Card(
        modifier = modifier.height(86.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .70f)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, modifier = Modifier.size(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(value, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun AppGrid(apps: List<LauncherApp>, onLaunch: (LauncherApp) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = Modifier.height(230.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        userScrollEnabled = false
    ) {
        items(apps) { app -> AppIcon(app, onLaunch) }
    }
}

@Composable
fun AppLibrary(apps: List<LauncherApp>, onLaunch: (LauncherApp) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Bibliothèque d’apps", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(15.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(apps) { app -> AppIcon(app, onLaunch) }
        }
    }
}

@Composable
fun AppIcon(app: LauncherApp, onLaunch: (LauncherApp) -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clickable { onLaunch(app) },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(app.color),
            contentAlignment = Alignment.Center
        ) {
            Icon(app.icon, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(app.label, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun Dock(apps: List<LauncherApp>, onLaunch: (LauncherApp) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(29.dp))
            .background(Color.White.copy(alpha = .52f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        apps.forEach { app ->
            AppIcon(app, onLaunch)
        }
    }
}

@Composable
fun PageIndicator(page: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(2) { index ->
            Box(
                Modifier
                    .size(if (index == page) 7.dp else 6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = if (index == page) .8f else .3f))
            )
        }
    }
}

@Composable
fun SearchOverlay(
    apps: List<LauncherApp>,
    onClose: () -> Unit,
    onLaunch: (LauncherApp) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = apps.filter { it.label.contains(query, true) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F7F9).copy(alpha = .97f))
            .padding(20.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, null)
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Rechercher") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(22.dp)
                )
            }
            Spacer(Modifier.height(18.dp))
            filtered.take(24).forEach { app ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onLaunch(app) }
                        .padding(vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)).background(app.color),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(app.icon, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(app.label, fontSize = 17.sp)
                }
            }
        }
    }
}

fun demoApps() = listOf(
    LauncherApp("Téléphone", Icons.Default.Phone, Color(0xFF39C76A)),
    LauncherApp("Messages", Icons.Default.Message, Color(0xFF35B95C)),
    LauncherApp("Photos", Icons.Default.Photo, Color(0xFFFF6A4D)),
    LauncherApp("Caméra", Icons.Default.CameraAlt, Color(0xFF222222)),
    LauncherApp("Musique", Icons.Default.MusicNote, Color(0xFFFF375F)),
    LauncherApp("Horloge", Icons.Default.AccessTime, Color(0xFF202020)),
    LauncherApp("Météo", Icons.Default.WbSunny, Color(0xFF4AA3FF)),
    LauncherApp("Réglages", Icons.Default.Settings, Color(0xFF7E8790))
)

fun loadApps(context: android.content.Context): List<LauncherApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }

    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
        .mapNotNull { info ->
            val label = info.loadLabel(pm)?.toString() ?: return@mapNotNull null
            val icon = when {
                label.contains("phone", true) || label.contains("téléphone", true) ->
                    Icons.Default.Phone
                label.contains("message", true) || label.contains("sms", true) ->
                    Icons.Default.Message
                label.contains("camera", true) || label.contains("caméra", true) ->
                    Icons.Default.CameraAlt
                label.contains("music", true) || label.contains("musique", true) ->
                    Icons.Default.MusicNote
                label.contains("setting", true) || label.contains("réglage", true) ->
                    Icons.Default.Settings
                else -> Icons.Default.Apps
            }
            LauncherApp(label, icon, Color(0xFF657AFA), info.activityInfo.packageName)
        }
        .distinctBy { it.packageName }
}

fun launchApp(context: android.content.Context, app: LauncherApp) {
    if (app.packageName == null) return
    val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
    if (launchIntent != null) context.startActivity(launchIntent)
}
