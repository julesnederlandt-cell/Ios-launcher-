# iOS Style Launcher V3

Une interface Android moderne inspirée des codes visuels d'un smartphone premium :
glassmorphism, widgets, dock translucide, bibliothèque d'apps, recherche et centre de contrôle.

## Fonctionnalités V3

- écran d'accueil avec widgets et dock
- vraies icônes des applications installées
- couleur de fond des icônes personnalisable
- mode icônes monochromes
- mode clair / sombre
- recherche type Spotlight
- bibliothèque d'applications
- centre de contrôle
- luminosité visuelle
- animations d'ouverture et d'appui
- balayage entre pages
- peut être défini comme launcher HOME Android
- workflow GitHub Actions qui génère l'APK

## Build GitHub

Le dépôt doit contenir les fichiers du projet, pas uniquement le ZIP.
Après push :
Actions -> Build APK V3 -> Run workflow.

L'APK debug sera disponible dans l'artifact :
ios-style-launcher-v3-debug
