package com.example.ios27launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.os.Bundle
import android.view.Window
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class LauncherApp(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)

private val themeColors = listOf(
    Color(0xFF5E72F4),
    Color(0xFF007AFF),
    Color(0xFF34C759),
    Color(0xFFFF2D55),
    Color(0xFFFF9500),
    Color(0xFFFFCC00),
    Color(0xFFAF52DE),
    Color(0xFF5856D6),
    Color(0xFF00C7BE),
    Color(0xFF111111)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MainActivityHolder.context = applicationContext
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme {
                LauncherV3()
            }
        }
    }
}

@Composable
private fun LauncherV3() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<LauncherApp>()) }
    var page by remember { mutableIntStateOf(0) }
    var iconTint by remember { mutableStateOf(themeColors[0]) }
    var monochrome by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var controlCenterOpen by remember { mutableStateOf(false) }
    var libraryOpen by remember { mutableStateOf(false) }
    var darkMode by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0.72f) }

    LaunchedEffect(Unit) {
        apps = loadLauncherApps(context)
    }

    val background = if (darkMode) {
        Brush.verticalGradient(
            listOf(Color(0xFF101116), Color(0xFF191B24), Color(0xFF0B0C10))
        )
    } else {
        Brush.verticalGradient(
            listOf(Color(0xFF9CCBFF), Color(0xFFEAF4FF), Color(0xFFF8F8FB))
        )
    }

    val foreground = if (darkMode) Color.White else Color(0xFF111217)
    val glass = if (darkMode) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.66f)

    Box(
        Modifier
            .fillMaxSize()
            .background(background)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, dragAmount ->
                        if (abs(dragAmount) > 70f) {
                            if (dragAmount < 0) page = (page + 1).coerceAtMost(1)
                            if (dragAmount > 0) page = (page - 1).coerceAtLeast(0)
                        }
                    }
                )
            }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 7.dp,
                    bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 5.dp,
                    start = 18.dp,
                    end = 18.dp
                )
        ) {
            StatusHeader(
                foreground = foreground,
                onSearch = { searchOpen = true },
                onControlCenter = { controlCenterOpen = true }
            )

            Spacer(Modifier.height(12.dp))

            AnimatedContent(targetState = page, label = "home-pages") { selected ->
                if (selected == 0) {
                    HomePage(
                        apps = apps,
                        iconTint = iconTint,
                        monochrome = monochrome,
                        darkMode = darkMode,
                        foreground = foreground,
                        glass = glass,
                        onLaunch = { launchApp(context, it) },
                        onLibrary = { libraryOpen = true }
                    )
                } else {
                    SecondaryPage(
                        apps = apps.drop(8),
                        iconTint = iconTint,
                        monochrome = monochrome,
                        darkMode = darkMode,
                        foreground = foreground,
                        onLaunch = { launchApp(context, it) }
                    )
                }
            }

            Spacer(Modifier.weight(1f))
            PageIndicator(page, darkMode)
            Spacer(Modifier.height(9.dp))

            Dock(
                apps = apps.take(4),
                tint = iconTint,
                monochrome = monochrome,
                glass = glass,
                onLaunch = { launchApp(context, it) }
            )

            Spacer(Modifier.height(7.dp))
            Box(
                Modifier
                    .width(115.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(foreground.copy(alpha = 0.70f))
                    .align(Alignment.CenterHorizontally)
            )
        }

        AnimatedVisibility(
            visible = searchOpen,
            enter = fadeIn(tween(160)) + scaleIn(tween(180), initialScale = 0.97f),
            exit = fadeOut(tween(130))
        ) {
            SearchOverlay(
                apps = apps,
                tint = iconTint,
                monochrome = monochrome,
                darkMode = darkMode,
                onClose = { searchOpen = false },
                onLaunch = { launchApp(context, it) }
            )
        }

        AnimatedVisibility(
            visible = settingsOpen,
            enter = slideInVertically(tween(250)) { it },
            exit = fadeOut(tween(160))
        ) {
            SettingsPanel(
                current = iconTint,
                monochrome = monochrome,
                darkMode = darkMode,
                onColor = { iconTint = it },
                onMonochrome = { monochrome = it },
                onDarkMode = { darkMode = it },
                onClose = { settingsOpen = false }
            )
        }

        AnimatedVisibility(
            visible = controlCenterOpen,
            enter = fadeIn(tween(150)) + scaleIn(tween(200), initialScale = 0.96f),
            exit = fadeOut(tween(140))
        ) {
            ControlCenter(
                darkMode = darkMode,
                brightness = brightness,
                onBrightness = { brightness = it },
                onDarkMode = { darkMode = !darkMode },
                onClose = { controlCenterOpen = false },
                onSettings = {
                    controlCenterOpen = false
                    settingsOpen = true
                }
            )
        }

        if (libraryOpen) {
            AppLibrary(
                apps = apps,
                tint = iconTint,
                monochrome = monochrome,
                darkMode = darkMode,
                onClose = { libraryOpen = false },
                onLaunch = { launchApp(context, it) }
            )
        }
    }
}

@Composable
private fun StatusHeader(
    foreground: Color,
    onSearch: () -> Unit,
    onControlCenter: () -> Unit
) {
    var time by remember { mutableStateOf(Date()) }

    LaunchedEffect(Unit) {
        while (true) {
            time = Date()
            delay(1000)
        }
    }

    val currentTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(time)

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            currentTime,
            color = foreground,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SignalCellularAlt, null, tint = foreground, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.Wifi, null, tint = foreground, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.BatteryFull, null, tint = foreground, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(10.dp))
            Icon(
                Icons.Default.Search,
                "Recherche",
                tint = foreground,
                modifier = Modifier.size(23.dp).clickable { onSearch() }
            )
            Spacer(Modifier.width(10.dp))
            Icon(
                Icons.Default.GridView,
                "Centre de contrôle",
                tint = foreground,
                modifier = Modifier.size(22.dp).clickable { onControlCenter() }
            )
        }
    }
}

@Composable
private fun HomePage(
    apps: List<LauncherApp>,
    iconTint: Color,
    monochrome: Boolean,
    darkMode: Boolean,
    foreground: Color,
    glass: Color,
    onLaunch: (LauncherApp) -> Unit,
    onLibrary: () -> Unit
) {
    Column {
        HeroWidget(darkMode, foreground, glass)

        Spacer(Modifier.height(13.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CompactWidget(
                title = "Batterie",
                value = "${batteryPercent()}%",
                icon = Icons.Default.BatteryFull,
                foreground = foreground,
                glass = glass,
                modifier = Modifier.weight(1f)
            )
            CompactWidget(
                title = "Musique",
                value = "Lecture",
                icon = Icons.Default.MusicNote,
                foreground = foreground,
                glass = glass,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(16.dp))

        val firstApps = apps.take(8)
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.height(268.dp),
            verticalArrangement = Arrangement.spacedBy(17.dp),
            horizontalArrangement = Arrangement.spacedBy(11.dp),
            userScrollEnabled = false
        ) {
            items(firstApps) {
                AppTile(
                    app = it,
                    tint = iconTint,
                    monochrome = monochrome,
                    foreground = foreground,
                    onClick = { onLaunch(it) }
                )
            }
        }

        Spacer(Modifier.height(5.dp))

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .clip(RoundedCornerShape(18.dp))
                .clickable { onLibrary() },
            color = glass
        ) {
            Row(
                Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.Apps, null, tint = foreground, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Bibliothèque d’apps", color = foreground, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun HeroWidget(darkMode: Boolean, foreground: Color, glass: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(176.dp),
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = glass),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(21.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(
                        SimpleDateFormat("EEEE", Locale.FRENCH).format(Date()).uppercase(),
                        color = foreground.copy(alpha = 0.72f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        SimpleDateFormat("d MMMM", Locale.FRENCH).format(Date()),
                        color = foreground,
                        fontSize = 29.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("18°", color = foreground, fontSize = 39.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(9.dp))
                    Text("Clair", color = foreground.copy(alpha = 0.82f), fontSize = 15.sp)
                }
            }

            Icon(
                Icons.Default.WbSunny,
                null,
                tint = if (darkMode) Color(0xFFFFD60A) else Color(0xFFFFB800),
                modifier = Modifier.size(52.dp)
            )
        }
    }
}

@Composable
private fun CompactWidget(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    foreground: Color,
    glass: Color,
    modifier: Modifier
) {
    Card(
        modifier = modifier.height(86.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = glass),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(icon, null, tint = foreground, modifier = Modifier.size(19.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(title, color = foreground, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(value, color = foreground.copy(alpha = 0.80f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AppTile(
    app: LauncherApp,
    tint: Color,
    monochrome: Boolean,
    foreground: Color,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = tween(130, easing = FastOutSlowInEasing),
        label = "icon-scale"
    )

    Column(
        Modifier
            .fillMaxWidth()
            .scale(scale)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClick() }
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(62.dp)
                .shadow(7.dp, RoundedCornerShape(18.dp), ambientColor = Color.Black.copy(alpha = 0.18f))
                .clip(RoundedCornerShape(18.dp))
                .background(tint),
            contentAlignment = Alignment.Center
        ) {
            val filter = if (monochrome) ColorFilter.tint(Color.White) else null
            androidx.compose.foundation.Image(
                bitmap = app.icon.toBitmap(96, 96).asImageBitmap(),
                contentDescription = app.label,
                modifier = Modifier.size(47.dp),
                contentScale = ContentScale.Fit,
                colorFilter = filter
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            app.label,
            color = foreground,
            fontSize = 11.sp,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun Dock(
    apps: List<LauncherApp>,
    tint: Color,
    monochrome: Boolean,
    glass: Color,
    onLaunch: (LauncherApp) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(91.dp)
            .clip(RoundedCornerShape(30.dp)),
        color = glass,
        tonalElevation = 0.dp
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 11.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            apps.forEach {
                Box(
                    Modifier
                        .size(62.dp)
                        .shadow(6.dp, RoundedCornerShape(18.dp), ambientColor = Color.Black.copy(alpha = 0.16f))
                        .clip(RoundedCornerShape(18.dp))
                        .background(tint)
                        .clickable { onLaunch(it) },
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.Image(
                        bitmap = it.icon.toBitmap(96, 96).asImageBitmap(),
                        contentDescription = it.label,
                        modifier = Modifier.size(46.dp),
                        colorFilter = if (monochrome) ColorFilter.tint(Color.White) else null
                    )
                }
            }
        }
    }
}

@Composable
private fun SecondaryPage(
    apps: List<LauncherApp>,
    iconTint: Color,
    monochrome: Boolean,
    darkMode: Boolean,
    foreground: Color,
    onLaunch: (LauncherApp) -> Unit
) {
    Column {
        Text(
            "Applications",
            color = foreground,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(15.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            items(apps) {
                AppTile(
                    it,
                    iconTint,
                    monochrome,
                    foreground,
                    onClick = { onLaunch(it) }
                )
            }
        }
    }
}

@Composable
private fun PageIndicator(page: Int, darkMode: Boolean) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.weight(1f))
        repeat(2) { index ->
            Box(
                Modifier
                    .size(if (index == page) 7.dp else 6.dp)
                    .clip(CircleShape)
                    .background(
                        if (darkMode) Color.White.copy(alpha = if (index == page) 0.9f else 0.28f)
                        else Color.Black.copy(alpha = if (index == page) 0.78f else 0.24f)
                    )
            )
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun SearchOverlay(
    apps: List<LauncherApp>,
    tint: Color,
    monochrome: Boolean,
    darkMode: Boolean,
    onClose: () -> Unit,
    onLaunch: (LauncherApp) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }.take(30)
    val bg = if (darkMode) Color(0xFF111217).copy(alpha = 0.98f) else Color(0xFFF7F7FA).copy(alpha = 0.98f)
    val fg = if (darkMode) Color.White else Color(0xFF111217)

    Box(Modifier.fillMaxSize().background(bg)) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 8.dp,
                    start = 17.dp,
                    end = 17.dp
                )
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, null, tint = fg)
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Rechercher") },
                    shape = RoundedCornerShape(22.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            filtered.forEach { app ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onLaunch(app) }
                        .padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(tint),
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.foundation.Image(
                            bitmap = app.icon.toBitmap(72, 72).asImageBitmap(),
                            contentDescription = app.label,
                            modifier = Modifier.size(38.dp),
                            colorFilter = if (monochrome) ColorFilter.tint(Color.White) else null
                        )
                    }
                    Spacer(Modifier.width(13.dp))
                    Text(app.label, color = fg, fontSize = 17.sp)
                }
            }
        }
    }
}

@Composable
private fun AppLibrary(
    apps: List<LauncherApp>,
    tint: Color,
    monochrome: Boolean,
    darkMode: Boolean,
    onClose: () -> Unit,
    onLaunch: (LauncherApp) -> Unit
) {
    val bg = if (darkMode) Color(0xFF101116) else Color(0xFFF4F5F9)
    val fg = if (darkMode) Color.White else Color(0xFF101116)

    Box(Modifier.fillMaxSize().background(bg)) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp,
                    bottom = 8.dp,
                    start = 17.dp,
                    end = 17.dp
                )
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Bibliothèque", color = fg, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, null, tint = fg)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "${apps.size} applications",
                color = fg.copy(alpha = 0.6f),
                fontSize = 13.sp
            )
            Spacer(Modifier.height(14.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                horizontalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                items(apps) {
                    AppTile(it, tint, monochrome, fg) { onLaunch(it) }
                }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    current: Color,
    monochrome: Boolean,
    darkMode: Boolean,
    onColor: (Color) -> Unit,
    onMonochrome: (Boolean) -> Unit,
    onDarkMode: (Boolean) -> Unit,
    onClose: () -> Unit
) {
    val panel = if (darkMode) Color(0xFF181A22) else Color(0xFFF7F7FA)
    val fg = if (darkMode) Color.White else Color(0xFF111217)

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.22f))) {
        Card(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            colors = CardDefaults.cardColors(panel)
        ) {
            Column(Modifier.padding(22.dp)) {
                Text("Personnalisation", color = fg, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Text("Couleur des icônes", color = fg, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))

                themeColors.chunked(5).forEach { row ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row.forEach { color ->
                            ColorChoice(color, selected = color == current) {
                                onColor(color)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                SettingRow(
                    title = "Icônes monochromes",
                    subtitle = "Utiliser une teinte uniforme",
                    icon = Icons.Default.Palette,
                    checked = monochrome,
                    foreground = fg,
                    onChecked = onMonochrome
                )

                SettingRow(
                    title = "Mode sombre",
                    subtitle = "Interface sombre",
                    icon = Icons.Default.DarkMode,
                    checked = darkMode,
                    foreground = fg,
                    onChecked = onDarkMode
                )

                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("Terminé")
                }
            }
        }
    }
}

@Composable
private fun ColorChoice(color: Color, selected: Boolean, onClick: () -> Unit) {
    val borderColor by animateColorAsState(
        if (selected) Color.Black.copy(alpha = 0.7f) else Color.Transparent,
        label = "color-border"
    )
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(color)
            .border(3.dp, borderColor, CircleShape)
            .clickable { onClick() }
    )
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    checked: Boolean,
    foreground: Color,
    onChecked: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = foreground, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = foreground, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = foreground.copy(alpha = 0.58f), fontSize = 12.sp)
        }
        androidx.compose.material3.Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun ControlCenter(
    darkMode: Boolean,
    brightness: Float,
    onBrightness: (Float) -> Unit,
    onDarkMode: () -> Unit,
    onClose: () -> Unit,
    onSettings: () -> Unit
) {
    val bg = if (darkMode) Color(0xFF14151B).copy(alpha = 0.98f) else Color(0xFFEFF0F5).copy(alpha = 0.98f)
    val fg = if (darkMode) Color.White else Color(0xFF111217)

    Box(Modifier.fillMaxSize().background(bg)) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 14.dp,
                    start = 17.dp,
                    end = 17.dp,
                    bottom = 10.dp
                )
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Centre de contrôle", color = fg, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Row {
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, null, tint = fg)
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, null, tint = fg)
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ControlTile("Wi‑Fi", Icons.Default.Wifi, true, fg, Modifier.weight(1f))
                ControlTile("Bluetooth", Icons.Default.Bluetooth, true, fg, Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ControlTile("Silencieux", Icons.Default.MusicNote, false, fg, Modifier.weight(1f))
                ControlTile("Lampe", Icons.Default.FlashlightOn, false, fg, Modifier.weight(1f))
            }

            Spacer(Modifier.height(16.dp))

            Card(
                Modifier.fillMaxWidth(),
                RoundedCornerShape(25.dp),
                colors = CardDefaults.cardColors(
                    if (darkMode) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.65f)
                ),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BrightnessHigh, null, tint = fg)
                        Spacer(Modifier.width(10.dp))
                        Text("Luminosité", color = fg, fontWeight = FontWeight.SemiBold)
                    }
                    Slider(
                        value = brightness,
                        onValueChange = onBrightness,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            ControlTile(
                title = "Mode sombre",
                icon = Icons.Default.DarkMode,
                active = darkMode,
                foreground = fg,
                modifier = Modifier.fillMaxWidth(),
                onClick = onDarkMode
            )

            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ControlTile("Verrouillage", Icons.Default.Lock, false, fg, Modifier.weight(1f))
                ControlTile("Appareil", Icons.Default.Smartphone, true, fg, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ControlTile(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    foreground: Color,
    modifier: Modifier,
    onClick: (() -> Unit)? = null
) {
    val bg = if (active) Color(0xFF5E72F4) else foreground.copy(alpha = 0.08f)
    Surface(
        modifier = modifier
            .height(82.dp)
            .clip(RoundedCornerShape(23.dp))
            .clickable(enabled = onClick != null) { onClick?.invoke() },
        color = bg
    ) {
        Column(
            Modifier.padding(15.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                icon,
                null,
                tint = if (active) Color.White else foreground,
                modifier = Modifier.size(23.dp)
            )
            Text(
                title,
                color = if (active) Color.White else foreground,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private fun loadLauncherApps(context: Context): List<LauncherApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }

    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .map { info: ResolveInfo ->
            LauncherApp(
                label = info.loadLabel(pm).toString(),
                packageName = info.activityInfo.packageName,
                activityName = info.activityInfo.name,
                icon = info.loadIcon(pm)
            )
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase(Locale.getDefault()) }
}

private fun launchApp(context: Context, app: LauncherApp) {
    val intent = Intent().apply {
        setClassName(app.packageName, app.activityName)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
}

private fun batteryPercent(): Int {
    return try {
        val manager = MainActivityHolder.context?.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        manager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.coerceIn(0, 100) ?: 87
    } catch (_: Exception) {
        87
    }
}

private object MainActivityHolder {
    var context: Context? = null
}
